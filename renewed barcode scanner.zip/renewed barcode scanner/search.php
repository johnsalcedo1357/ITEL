<?php
include 'db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['barcode'])) {
    $barcode = $_POST['barcode'];

    $stmt = $conn->prepare("SELECT * FROM item WHERE barcode = ?");
    $stmt->bind_param("s", $barcode);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $insertstmt = $conn->prepare("INSERT INTO temp (name, price) VALUES (?, ?)");
            $insertstmt->bind_param("sd", $row['name'], $row['price']);

            if ($insertstmt->execute()) {
                echo "Inserted into temp: " . htmlspecialchars($row['name']) . " - " . htmlspecialchars($row['price']) . "<br>";
            } else {
                echo "Insertion error: " . htmlspecialchars($insertstmt->error) . "<br>";
            }
            $insertstmt->close();
        }
    } else {
        $message = "No item found with that barcode.";
    }
    $stmt->close();

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

$tempstmt = $conn->prepare("SELECT * FROM temp");
$tempstmt->execute();
$tempResult = $tempstmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="search.css">
</head>
<body>
    <?php
    if ($tempResult->num_rows > 0) {
        while ($tempRow = $tempResult->fetch_assoc()) {
            echo "Temp Name: " . htmlspecialchars($tempRow['name']) . " - Price: " . htmlspecialchars($tempRow['price']) . "<br>";
        }
    } else {
        echo "No items in the temp table.";
    }
    ?>
    <form method="POST">
        <button type="submit" name="add_all">Add all</button>
    </form>
    <?php if (!empty($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
</body>
</html>
<?php
$tempstmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_all'])) {
    $totalstmt = $conn->prepare("SELECT SUM(price) AS total_price FROM temp");
    $totalstmt->execute();
    $totalResult = $totalstmt->get_result();
    $totalRow = $totalResult->fetch_assoc();

    if ($totalRow && $totalRow['total_price'] !== null) {
        $message = "Total Price: " . htmlspecialchars($totalRow['total_price']);
    } else {
        $message = "No items in the temp table.";
    }

    $totalstmt->close();
}
?>
