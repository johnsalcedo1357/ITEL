function show(itemname, itemprice, itemid) {
    const div = document.getElementById('window');
    const name = document.getElementById('itemname');
    const price = document.getElementById('itemprice');
    const id = document.getElementById('itemid');

    name.value = itemname;
    price.value = itemprice;
    id.value = itemid;

    div.style.display = 'block';
    setTimeout(() => {
        document.addEventListener('click', handleClickOutside);
    }, 10);
}

function index() {
    window.location.href = 'index.php';
}
function add() {
    window.location.href = 'index.php';
}